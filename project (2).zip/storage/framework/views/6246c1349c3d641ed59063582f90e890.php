<?php $__env->startSection('title', 'Detail Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm p-4">
    <div class="mb-3">
        <a href="<?php echo e(route('reports.index')); ?>" class="text-decoration-none">&larr; Kembali ke dashboard</a>
    </div>

    <h2 class="fw-bold"><?php echo e($report->title); ?></h2>
    <p class="text-secondary"><?php echo e($report->infrastructure_type); ?></p>

    <p><?php echo e($report->description); ?></p>

    <p><b>Pelapor:</b> <?php echo e($report->reporter_name); ?></p>
    <p><b>Alamat:</b> <?php echo e($report->address); ?></p>
    <p>
        <b>Status:</b> <span class="badge text-bg-secondary"><?php echo e($report->status); ?></span> <br>
        <b>Prioritas:</b> <span class="badge text-bg-info"><?php echo e($report->priority); ?></span>
    </p>

    <div class="row mt-4">
        <div class="col-md-6 mb-3">
            <h5 class="fw-bold">📸 Foto Kondisi Awal (Before)</h5>
            <?php if($report->photo_path): ?>
                <img src="<?php echo e(asset('storage/' . $report->photo_path)); ?>" class="img-fluid rounded border" style="max-height:300px; width:100%; object-fit:cover;">
            <?php else: ?>
                <div class="alert alert-secondary text-center">Tidak ada foto awal.</div>
            <?php endif; ?>
        </div>

        <div class="col-md-6 mb-3">
            <h5 class="fw-bold text-success">✅ Foto Hasil Perbaikan (After)</h5>
            <?php if($report->after_photo_path): ?>
                <img src="<?php echo e(asset('storage/' . $report->after_photo_path)); ?>" class="img-fluid rounded border" style="max-height:300px; width:100%; object-fit:cover;">
            <?php else: ?>
                <div class="alert alert-warning text-center">Belum ada bukti perbaikan.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- FORM UPLOAD AFTER -->
    <?php if(auth()->check() && auth()->user()->role === 'petugas'): ?>
    <div class="card bg-light border-0 mt-2 mb-4">
        <div class="card-body">
            <h6 class="fw-bold">Unggah Bukti Perbaikan (Simulasi Petugas)</h6>
            <form action="<?php echo e(route('reports.after', $report)); ?>" method="POST" enctype="multipart/form-data" class="d-flex gap-2 align-items-center">
                <?php echo csrf_field(); ?>
                <input class="form-control" type="file" name="after_photo" accept="image/*" required>
                <button class="btn btn-success text-nowrap">Upload Foto After</button>
            </form>
            <?php $__errorArgs = ['after_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="mt-3">
        <h5 class="fw-bold">Peta Lokasi</h5>
        <div id="map-detail"></div>
    </div>

    <?php if($report->traffic_volume && $report->remaining_width): ?>
        <div class="alert alert-info mt-4">
            <h5 class="fw-bold">🚦 Analisis Dampak Lalu Lintas</h5>
            <?php
                $kapasitasPerMeter = 1500 / 3.5;
                $kapasitasSisa = $kapasitasPerMeter * $report->remaining_width;
                $pembagi = max(1, $kapasitasSisa);
                $rasio = $report->traffic_volume / $pembagi;
            ?>
            <p class="mb-1">Lebar sisa: <b><?php echo e($report->remaining_width); ?> meter</b> | Volume: <b><?php echo e($report->traffic_volume); ?> kend/jam</b></p>
            <?php if($rasio > 1): ?>
                <p class="text-danger fw-bold mb-0">⚠️ TRAFFIC JAM: Volume melebihi kapasitas sisa! Rasio (V/C) = <?php echo e(number_format($rasio, 2)); ?>. Perbaikan jalan ini SANGAT MENDESAK.</p>
            <?php else: ?>
                <p class="text-success fw-bold mb-0">✅ Lalu lintas masih terkendali. Rasio (V/C) = <?php echo e(number_format($rasio, 2)); ?>.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- KALKULATOR MATERIAL (RAB) -->
    <?php if(auth()->check() && auth()->user()->role === 'petugas'): ?>
    <div class="card bg-light border-0 mt-4 mb-4">
        <div class="card-body">
            <h5 class="fw-bold">🏗️ Kalkulator Kebutuhan Material (RAB)</h5>
            <p class="text-secondary small">Masukkan dimensi kerusakan untuk menghitung kebutuhan aspal.</p>

            <form action="<?php echo e(route('reports.material', $report)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Panjang (m)</label>
                        <input type="number" step="0.01" class="form-control" name="damage_length" value="<?php echo e($report->damage_length); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Lebar (m)</label>
                        <input type="number" step="0.01" class="form-control" name="damage_width" value="<?php echo e($report->damage_width); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tebal/Kedalaman (cm)</label>
                        <input type="number" step="0.01" class="form-control" name="damage_depth" value="<?php echo e($report->damage_depth); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-warning w-100 fw-bold">Hitung Material</button>
                    </div>
                </div>
            </form>

            <?php if($report->damage_length && $report->damage_width && $report->damage_depth): ?>
                <?php
                    // Konversi cm ke meter
                    $tebal_m = $report->damage_depth / 100;
                    // Hitung Volume (m3)
                    $volume = $report->damage_length * $report->damage_width * $tebal_m;
                    // Berat jenis aspal padat rata-rata = 2.3 Ton/m3
                    $berat_aspal = $volume * 2.3;
                ?>

                <div class="alert alert-success mt-3 mb-0">
                    <h6 class="fw-bold mb-2">📊 Hasil Perhitungan:</h6>
                    <ul class="mb-0">
                        <li>Volume Pekerjaan: <b><?php echo e(number_format($volume, 3)); ?> m³</b></li>
                        <li>Estimasi Kebutuhan Aspal: <b><?php echo e(number_format($berat_aspal, 2)); ?> Ton</b></li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- FORM UBAH STATUS -->
    <?php if(auth()->check() && auth()->user()->role === 'petugas'): ?>
    <hr class="my-4">
    <h5 class="fw-bold">Perbarui status (simulasi petugas)</h5>
    <form action="<?php echo e(route('reports.status', $report)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="row g-2">
            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select class="form-select" name="status">
                    <?php $__currentLoopData = ['Menunggu','Diverifikasi','Diproses','Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php if($report->status === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Prioritas</label>
                <select class="form-select" name="priority">
                    <?php $__currentLoopData = ['Rendah','Sedang','Tinggi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p); ?>" <?php if($report->priority === $p): echo 'selected'; endif; ?>><?php echo e($p); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <button class="btn btn-primary mt-3">Simpan perubahan</button>
    </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>#map-detail { height: 300px; border-radius: 10px; margin-top: 15px; }</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        const latAwal = <?php echo e($report->latitude ?? -7.5); ?>;
        const lngAwal = <?php echo e($report->longitude ?? 110.8); ?>;
        const mapDetail = L.map('map-detail').setView([latAwal, lngAwal], 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(mapDetail);
        <?php if($report->geometry): ?>
            const coords = <?php echo $report->geometry; ?>;
            const latlngs = coords.map(c => [c.lat, c.lng]);
            L.polyline(latlngs, {color: 'red', weight: 5}).addTo(mapDetail);
            mapDetail.fitBounds(L.polyline(latlngs).getBounds());
        <?php elseif($report->latitude && $report->longitude): ?>
            L.marker([<?php echo e($report->latitude); ?>, <?php echo e($report->longitude); ?>]).addTo(mapDetail);
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\civicheck\resources\views/reports/show.blade.php ENDPATH**/ ?>