<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'CIVICHECK'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        body { background:#f4f7fa; }
        .brand { color:#123b5d; font-weight:800; letter-spacing:.5px; }
        .hero { background:#123b5d; color:white; border-radius:18px; }
        .card { border:0; border-radius:14px; }
        #map { height:360px; border-radius:14px; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-white shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand brand" href="<?php echo e(route('reports.index')); ?>">CIVICHECK</a>

            <div class="d-flex align-items-center gap-3">
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('reports.create')); ?>">+ Laporkan Kerusakan</a>

                <?php if(auth()->guard()->check()): ?>
                    <span class="text-secondary small">Halo, <?php echo e(Auth::user()->name); ?></span>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-secondary btn-sm">Login Petugas</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container pb-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\civicheck\resources\views/layouts/app.blade.php ENDPATH**/ ?>