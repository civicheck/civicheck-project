<?php $__env->startSection('title', 'Dashboard CIVICHECK'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero p-4 p-md-5 mb-4">
    <h1 class="fw-bold">Pantau Infrastruktur di Sekitarmu</h1>
    <p class="mb-3">Laporkan kerusakan jalan dan drainase agar dapat ditindaklanjuti.</p>
    <a class="btn btn-warning fw-semibold" href="<?php echo e(route('reports.create')); ?>">Buat Laporan</a>
</div>

<!-- KOTAK RINGKASAN -->
<div class="row g-3 mb-4">
    <?php $__currentLoopData = [
        ['Total Laporan', $reports->count()],
        ['Menunggu', $reports->where('status','Menunggu')->count()],
        ['Diproses', $reports->where('status','Diproses')->count()],
        ['Selesai', $reports->where('status','Selesai')->count()]
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-6 col-lg-3">
        <div class="card shadow-sm p-3">
            <div class="text-secondary small"><?php echo e($item[0]); ?></div>
            <div class="fs-2 fw-bold"><?php echo e($item[1]); ?></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row mb-4">
    <!-- BAGIAN GRAFIK BARU -->
    <div class="col-md-5 mb-3">
        <div class="card shadow-sm p-3 h-100">
            <h5 class="fw-bold">Statistik Kerusakan</h5>
            <p class="text-secondary small">Berdasarkan jenis infrastruktur.</p>
            <div class="d-flex justify-content-center align-items-center" style="height: 250px;">
                <canvas id="chartJenis"></canvas>
            </div>
        </div>
    </div>

    <!-- BAGIAN PETA -->
    <div class="col-md-7 mb-3">
        <div class="card shadow-sm p-3 h-100">
            <h5 class="fw-bold">Peta Laporan</h5>
            <p class="text-secondary small">Titik dan garis hanya muncul jika pelapor mengisi koordinat atau menggambar garis.</p>
            <div id="map" style="height: 300px;"></div>
        </div>
    </div>
</div>

<!-- TABEL LAPORAN & PENCARIAN -->
<div class="card shadow-sm p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0">Daftar Laporan</h5>

        <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Cari judul / alamat..." value="<?php echo e(request('search')); ?>">
            <select name="status" class="form-select form-select-sm" style="width: 130px;">
                <option value="Semua" <?php if(request('status') == 'Semua'): echo 'selected'; endif; ?>>Semua Status</option>
                <option value="Menunggu" <?php if(request('status') == 'Menunggu'): echo 'selected'; endif; ?>>Menunggu</option>
                <option value="Diverifikasi" <?php if(request('status') == 'Diverifikasi'): echo 'selected'; endif; ?>>Diverifikasi</option>
                <option value="Diproses" <?php if(request('status') == 'Diproses'): echo 'selected'; endif; ?>>Diproses</option>
                <option value="Selesai" <?php if(request('status') == 'Selesai'): echo 'selected'; endif; ?>>Selesai</option>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Cari</button>
            <?php if(request('search') || (request('status') && request('status') !== 'Semua')): ?>
                <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-sm btn-light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Jenis</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($report->title); ?></td>
                    <td><?php echo e($report->infrastructure_type); ?></td>
                    <td><?php echo e($report->address); ?></td>
                    <td><span class="badge text-bg-secondary"><?php echo e($report->status); ?></span></td>
                    <td><a href="<?php echo e(route('reports.show', $report)); ?>" class="btn btn-sm btn-outline-primary">Lihat</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-secondary">Tidak ada laporan yang cocok dengan pencarianmu.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Script Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // === 1. SCRIPT UNTUK GRAFIK ===
    const countJalan = <?php echo e($reports->where('infrastructure_type', 'Jalan')->count()); ?>;
    const countDrainase = <?php echo e($reports->where('infrastructure_type', 'Drainase')->count()); ?>;

    const ctx = document.getElementById('chartJenis').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut', // Jenis grafik: donat
        data: {
            labels: ['Jalan', 'Drainase'],
            datasets: [{
                data: [countJalan, countDrainase],
                backgroundColor: ['#0d6efd', '#198754'], // Warna Biru dan Hijau
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // === 2. SCRIPT UNTUK PETA ===
    const rawData = <?php echo json_encode($reports->toArray()); ?>;

    const map = L.map('map').setView([-7.5, 110.8], 8);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    rawData.forEach(r => {
        if (r.latitude && r.longitude) {
            L.marker([parseFloat(r.latitude), parseFloat(r.longitude)]).addTo(map)
             .bindPopup(`<b>${r.title}</b><br>Status: ${r.status}`);
        }

        if (r.geometry) {
            try {
                const coords = JSON.parse(r.geometry);
                const latlngs = coords.map(c => [c.lat, c.lng]);
                L.polyline(latlngs, {color: 'red', weight: 5}).addTo(map)
                 .bindPopup(`<b>${r.title}</b><br>Ruas jalan rusak`);
            } catch (e) {
                console.error("Format geometri tidak valid");
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\civicheck\resources\views/reports/index.blade.php ENDPATH**/ ?>